import os
import numpy as np
import pandas as pd
from sklearn.cluster import OPTICS
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score
from scipy.stats import mode
import warnings
from functools import lru_cache

warnings.filterwarnings("ignore")

# پارامترهای الگوریتم
N, T, G, D = 20, 5, 20, 2
weights = np.array([[i / (N - 1), 1 - i / (N - 1)] for i in range(N)])

def find_neighbors(weights, T):
    neighbors = []
    for i, w in enumerate(weights):
        dists = np.linalg.norm(weights - w, axis=1)
        idx = np.argsort(dists)[:T]
        neighbors.append(idx)
    return np.array(neighbors)

neighbors = find_neighbors(weights, T)

def run_moead_optics(X_train, y_train, X_val, y_val):
    @lru_cache(maxsize=None)
    def evaluate_cached(min_samples, xi):
        optics = OPTICS(min_samples=min_samples, xi=xi)
        cluster_labels = optics.fit_predict(X_train)
        mask = cluster_labels != -1
        if np.sum(mask) == 0:
            return (1e5, 1), 0.0
        valid_labels = cluster_labels[mask]
        true_valid = y_train[mask]
        mapped_labels = np.zeros_like(valid_labels)
        for i in np.unique(valid_labels):
            idx = (valid_labels == i)
            if np.any(idx):
                mapped_labels[idx] = mode(true_valid[idx], keepdims=True).mode[0]
        acc = accuracy_score(true_valid, mapped_labels)
        noise_ratio = 1 - len(valid_labels) / len(X_train)
        return (noise_ratio, 1 - acc), acc

    def evaluate(ind):
        min_samples = int(round(ind[0]))
        min_samples = max(2, min(min_samples, 10))
        xi = float(np.clip(ind[1], 0.01, 0.5))
        return evaluate_cached(min_samples, xi)

    def tchebycheff(f, w, z):
        return np.max(w * np.abs(f - z))

    population = np.zeros((N, D))
    population[:, 0] = np.random.randint(2, 10, size=N)
    population[:, 1] = np.random.uniform(0.01, 0.5, size=N)

    ideal = np.full(2, np.inf)
    best_acc = 0
    best_solution = None

    for gen in range(G):
        for i in range(N):
            P = neighbors[i]
            a, b = np.random.choice(P, 2, replace=False)
            x1, x2, x3 = population[i], population[a], population[b]
            F_de = 0.5
            mutant = x1 + F_de * (x2 - x3)
            mutant[0] = np.clip(mutant[0], 2, 10)
            mutant[1] = np.clip(mutant[1], 0.01, 0.5)
            f_y, acc_y = evaluate(mutant)
            ideal = np.minimum(ideal, f_y)
            for j in P:
                f_j, _ = evaluate(population[j])
                if tchebycheff(f_y, weights[j], ideal) < tchebycheff(f_j, weights[j], ideal):
                    population[j] = mutant
                    if acc_y > best_acc:
                        best_acc = acc_y
                        best_solution = mutant.copy()

    # استفاده از بهترین پارامتر روی داده‌ی اعتبارسنجی
    min_samples = int(round(best_solution[0]))
    xi = float(round(best_solution[1], 3))
    optics = OPTICS(min_samples=min_samples, xi=xi)
    val_labels = optics.fit_predict(X_val)
    mask = val_labels != -1
    if np.sum(mask) == 0:
        return 0.0
    mapped = np.zeros_like(val_labels[mask])
    for i in np.unique(val_labels[mask]):
        idx = val_labels[mask] == i
        if np.any(idx):
            mapped[idx] = mode(y_val[mask][idx], keepdims=True).mode[0]
    acc_val = accuracy_score(y_val[mask], mapped)
    return acc_val * 100


# ---------- اجرای اصلی ----------
dataset_path = "datasets/breast_diagnostic.csv"  # مسیر دیتاست
df = pd.read_csv(dataset_path)
X = df.iloc[:, :-1].values
y = df.iloc[:, -1].values
if y.dtype == 'O':
    y = LabelEncoder().fit_transform(y)
X = StandardScaler().fit_transform(X)

kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
fold_accuracies = []

for fold, (train_idx, val_idx) in enumerate(kfold.split(X, y), 1):
    X_train, X_val = X[train_idx], X[val_idx]
    y_train, y_val = y[train_idx], y[val_idx]
    acc = run_moead_optics(X_train, y_train, X_val, y_val)
    fold_accuracies.append(acc)
    print(f"Fold {fold} → Accuracy: {acc:.2f}%")

mean_acc = np.mean(fold_accuracies)
print(f"\n✅ Average Cross-Validation Accuracy: {mean_acc:.2f}%")
