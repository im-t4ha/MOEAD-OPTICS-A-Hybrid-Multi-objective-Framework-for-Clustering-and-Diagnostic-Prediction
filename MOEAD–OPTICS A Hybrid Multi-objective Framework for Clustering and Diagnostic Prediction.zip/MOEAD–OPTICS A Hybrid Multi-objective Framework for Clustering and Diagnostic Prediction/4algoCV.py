import os
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN, MeanShift
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.impute import SimpleImputer
from scipy.stats import mode
import warnings

warnings.filterwarnings("ignore")

DATASET_FOLDER = 'datasets'

clustering_algorithms = {
    'KMeans': KMeans(random_state=42),
    'AgglomerativeClustering': AgglomerativeClustering(),
    'DBSCAN': DBSCAN(eps=0.5, min_samples=5),
    'MeanShift': MeanShift()
}

def map_labels(pred_labels, true_labels):
    mapped = np.zeros_like(pred_labels)
    for i in np.unique(pred_labels):
        mask = pred_labels == i
        if np.any(mask):
            mapped[mask] = mode(true_labels[mask], keepdims=True).mode[0]
    return mapped

results = []

for filename in os.listdir(DATASET_FOLDER):
    if filename.endswith('.csv'):
        path = os.path.join(DATASET_FOLDER, filename)
        df = pd.read_csv(path)

        print(f'\n🔄 Processing {filename}...')

        X_all = df.iloc[:, :-1]
        y_all = df.iloc[:, -1].values

        if y_all.dtype == 'O':
            y_all = LabelEncoder().fit_transform(y_all)

        # فقط ویژگی‌های عددی
        X_numeric = X_all.select_dtypes(include=['number'])
        if X_numeric.shape[1] == 0:
            print(f'Skipping {filename}: no numeric features.')
            continue

        X_imputed = SimpleImputer(strategy='mean').fit_transform(X_numeric)
        X_scaled = StandardScaler().fit_transform(X_imputed)

        kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        fold_scores = {name: [] for name in clustering_algorithms}

        for fold, (train_idx, test_idx) in enumerate(kfold.split(X_scaled, y_all), 1):
            X_train, X_test = X_scaled[train_idx], X_scaled[test_idx]
            y_train, y_test = y_all[train_idx], y_all[test_idx]

            for name, algo in clustering_algorithms.items():
                try:
                    # اگر الگوریتم نیاز به تعداد خوشه داشته باشه، ست می‌کنیم
                    if name in ['KMeans', 'AgglomerativeClustering']:
                        algo.set_params(n_clusters=len(np.unique(y_all)))

                    preds = algo.fit_predict(X_test)
                    mask = preds != -1
                    if np.sum(mask) == 0:
                        acc = 0.0
                    else:
                        mapped = map_labels(preds[mask], y_test[mask])
                        acc = accuracy_score(y_test[mask], mapped) * 100
                except Exception as e:
                    acc = 0.0

                fold_scores[name].append(round(acc, 2))

        # میانگین دقت‌ها در 5 فولد
        result_row = {'Dataset': filename}
        for name in clustering_algorithms:
            mean_acc = np.mean(fold_scores[name])
            result_row[name] = round(mean_acc, 2)

        results.append(result_row)

# ذخیره خروجی
df_results = pd.DataFrame(results)
df_results.to_excel('clustering_cv_accuracy_results.xlsx', index=False)
print("\n✅ خروجی ذخیره شد → clustering_cv_accuracy_results.xlsx")
