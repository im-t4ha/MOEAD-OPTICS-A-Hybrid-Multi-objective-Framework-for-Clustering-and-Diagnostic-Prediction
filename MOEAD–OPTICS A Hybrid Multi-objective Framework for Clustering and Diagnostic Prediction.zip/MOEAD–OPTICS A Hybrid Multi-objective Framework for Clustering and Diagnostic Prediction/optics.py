import os
import pandas as pd
import numpy as np
from sklearn.cluster import OPTICS
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import StratifiedKFold
from scipy.stats import mode

def optics_accuracy(X_train, y_train, X_test, y_test):
    optics = OPTICS(min_samples=5, xi=0.05, min_cluster_size=0.1)
    optics.fit(X_train)
    labels = optics.fit_predict(X_test)

    mask = labels != -1
    if np.sum(mask) == 0:
        return 0.0

    labels_filtered = labels[mask]
    y_filtered = y_test[mask]

    y_pred_aligned = np.zeros_like(labels_filtered)
    for cluster in np.unique(labels_filtered):
        idx = labels_filtered == cluster
        most_common = mode(y_filtered[idx], keepdims=True).mode[0]
        y_pred_aligned[idx] = most_common

    return accuracy_score(y_filtered, y_pred_aligned) * 100

def preprocess_features(X_df):
    X_processed = X_df.copy()
    for col in X_processed.columns:
        if X_processed[col].dtype == object:
            le = LabelEncoder()
            X_processed[col] = le.fit_transform(X_processed[col])
    return X_processed.values

def main():
    folder = "datasets"
    results = []
    k_folds = 5  # تعداد فولدها

    for filename in os.listdir(folder):
        if filename.endswith(".csv"):
            path = os.path.join(folder, filename)
            df = pd.read_csv(path).dropna()

            X_df = df.iloc[:, :-1]
            y = df.iloc[:, -1].values

            X = preprocess_features(X_df)

            if not pd.api.types.is_numeric_dtype(df.iloc[:, -1]):
                y = LabelEncoder().fit_transform(y)

            skf = StratifiedKFold(n_splits=k_folds, shuffle=True, random_state=42)
            fold_accuracies = []

            try:
                for train_idx, test_idx in skf.split(X, y):
                    X_train, X_test = X[train_idx], X[test_idx]
                    y_train, y_test = y[train_idx], y[test_idx]

                    acc = optics_accuracy(X_train, y_train, X_test, y_test)
                    fold_accuracies.append(acc)

                avg_acc = np.mean(fold_accuracies)
                results.append({"Dataset": filename, "Accuracy (%)": round(avg_acc, 2)})
                print(f"{filename} --> Average Accuracy (CV): {avg_acc:.2f}%")

            except Exception as e:
                print(f"{filename} --> Error: {e}")

    results_df = pd.DataFrame(results)
    results_df.to_excel("optics_cv_accuracy_results.xlsx", index=False)
    print("\n✅ نتایج در فایل optics_cv_accuracy_results.xlsx ذخیره شدند.")

if __name__ == "__main__":
    main()
